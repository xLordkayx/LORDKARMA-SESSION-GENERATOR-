## Old Version Fork Members Please Fork Again this repository___👨‍💻📃
<br>
Get New Version__😎✔
  
  <p align="center">
<a href="https://github.com/MrMasterOfc/SESSION-GENERATE/fork" target="blank"><img align="center" src="https://i.imgur.com/cxaSEWe.png" alt="Deploy bot" height="112" width="310" /></a>
     
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">
   <p align="center">
<a href="https://github.com/MrMasterOfc">
    <img src="https://telegra.ph/file/c227d87605ffa07c7871c.png" width="700px">
  </a>
<img src="https://user-images.githubusercontent.com/73097560/115834477-dbab4500-a447-11eb-908a-139a6edaec5c.gif">



# 👨‍💻 *SESSION MADE BY MASTER MIND* 👨‍💻


## *NOTE*
- *SESSION ID GENERATOR FOR X-ASENA AND SECKTOR MD BASED BOTS*
- *IN ORDER TO USE PAIR CODE AND SESSION ID'S YOU HAVE TO USE*
- *OTHER-WISE THE PAIR CODE WILL NOT WORK AND NOR SESSIOND ID'S*


## *DEPLOYMENT METHODS*
- ***DEPLOY ON `HEROKU` OR `RENDER` OR ANY PLATFROM YOU LIKE***
- ***CREATE HEROKU OR RENDER ACCOUNT***
- ***CREATE NEW APP AND CONNECT YOUR REPOSITORY USING GITHUB***
- ***THEN DEPLOY THE REPO AND BOOM 💥***
- ***DON'T FORGOT TO STAR THE REPO***

 <details close>
<summary>HOW TO DEPLOY 👨‍💻 SESSON-GENERATER 👨‍💻</summary>
   
    1: First Fork the Repo.
    2: Then Go to Heroku Web Page
    3: Create Heroku App
    4: Add Heroku Postgres package
    5: Click Deploy Tab And Add Github Your fork Repostory
    6: Click Deploy Branch
    7: Click view
    8: Enjoy
   </details>


## DEPLOY VIDEO
[Click](https://www.youtube.com/watch?v=Gsswl2Ojp3Q)

<br>


[`Helper`](https://wa.me/+94720797915?text=Session_Problem😢)
